<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/_params.html.twig */
class __TwigTemplate_a901f2bebe6cad5508942b38caf49c027119f42bc8f5b053a3090e15654c4b7b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "components/_params.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "components/_params.html.twig"));

        // line 1
        echo "
<div class=\"fixed-plugin\">
    <div class=\"dropdown toggle\">
        <a href=\"#\" data-toggle=\"dropdown\">
            <i class=\"fa fa-cog fa-2x\"> </i>
        </a>
        <ul class=\"dropdown-menu\">
            ";
        // line 14
        echo "
            <h4> Mes parametres</h4>

            <li class=\"\">
                <a href=\"http://localhost:8000/profil\" class=\"switch\">
                    <button id=\"boutonformule\" type=\"button\" class=\"btn btn-outline-primary\">Modifier mon profil
                    </button>
                </a>
            </li>

            <li class=\"\">
                <a href=\"http://localhost:8000/updatemdp\" class=\"switch\">
                    <button id=\"boutonformule\" type=\"button\" class=\"btn btn-outline-primary\">Modifier mon mot de passe
                    </button>
                </a>
            </li>


        </ul>
    </div>
</div> <!--/PARAMETRE-->
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "components/_params.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  52 => 14,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
<div class=\"fixed-plugin\">
    <div class=\"dropdown toggle\">
        <a href=\"#\" data-toggle=\"dropdown\">
            <i class=\"fa fa-cog fa-2x\"> </i>
        </a>
        <ul class=\"dropdown-menu\">
            {#<li class=\"header-title\">{% block title %}Test affichage{% endblock %}</li> #}
{#            <li class=\"active\">#}
{#                <a href=\"#\" class=\"switch\">#}
{#                    <p class=\"\">Changer mon nom</p>#}
{#                </a>#}
{#            </li>#}

            <h4> Mes parametres</h4>

            <li class=\"\">
                <a href=\"http://localhost:8000/profil\" class=\"switch\">
                    <button id=\"boutonformule\" type=\"button\" class=\"btn btn-outline-primary\">Modifier mon profil
                    </button>
                </a>
            </li>

            <li class=\"\">
                <a href=\"http://localhost:8000/updatemdp\" class=\"switch\">
                    <button id=\"boutonformule\" type=\"button\" class=\"btn btn-outline-primary\">Modifier mon mot de passe
                    </button>
                </a>
            </li>


        </ul>
    </div>
</div> <!--/PARAMETRE-->
", "components/_params.html.twig", "C:\\xampp\\htdocs\\billydocs\\billydocs\\billydocs-master\\templates\\components\\_params.html.twig");
    }
}
