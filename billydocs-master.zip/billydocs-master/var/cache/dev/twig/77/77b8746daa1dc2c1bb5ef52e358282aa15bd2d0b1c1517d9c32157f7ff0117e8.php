<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/home.html.twig */
class __TwigTemplate_b18f5ab851c216b85637ac5ed094975369a9f5501de6e89fa9472acbdde82873 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/home.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/home.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "home/home.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    ";
        $this->loadTemplate("components/_nav.html.twig", "home/home.html.twig", 4)->display($context);
        // line 5
        echo "    <div class=\"section section-features\">
        <div class=\"container\">
            <h2 class=\"header-text text-center\">Vos documents</h2>
            <div class=\"row\">
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-portfolio\"></i>
                        </div>
                        <div class=\"text\">
                            <p>All appointments sync with your Google calendar so your availability is always up to
                                date. See your schedule at a glance from any device.</p>
                        </div>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-portfolio\"></i>
                        </div>
                        <p>Automatic text and email reminders make sure customers always remember their upcoming
                            appointments.</p>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-portfolio\"></i>
                        </div>
                        <p>Take payments and run your business on the go, in your store and then see how it all adds up
                            with analytics.</p>
                    </div>
                </div>
            </div>
        </div>
    </div> <!--/CARDS DOCS-->


    <!--CARDS FORMULES-->
    <div class=\"section section-features\">
        <div class=\"container\">
            <h2 id=\"formules\" class=\"header-text text-center\">Formules</h2>
            <div class=\"row\">
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-magic-wand\"></i>
                        </div>
                        <div class=\"text\">
                            <h3>Gratuit</h3>
                            <h3>0€ <span>/mois</span></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto magnam, consequatur sint
                                officiis. Blanditiis numquam officia nobis id iure sed doloribus, adipisci, maiores
                                harum totam ratione ad nostrum ipsum iste?</p>

                        </div>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-pendrive\"></i>
                        </div>
                        <h3>Plus</h3>
                        <h3>5.50€ <span>/mois</span></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione tempora vero nemo placeat
                            fuga, vitae pariatur dolorum ab! Doloribus qui autem fugiat voluptate tempore, eaque
                            perferendis quibusdam tempora, quis arc</p>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-server\"></i>
                        </div>
                        <h3>Pro</h3>
                        <h3>15.90€ <span>/mois</span></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae in libero voluptatibus ut,
                            eaque provident blanditiis aut impedit modi quos laboriosam repellat iste quia tenetur
                            sapiente. Quasi expedita, exercitationem a!</p>
                    </div>
                </div>
            </div>
        </div>
    </div> <!--/CARDS FORMULES-->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "home/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 5,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}

{% block content %}
    {% include 'components/_nav.html.twig' %}
    <div class=\"section section-features\">
        <div class=\"container\">
            <h2 class=\"header-text text-center\">Vos documents</h2>
            <div class=\"row\">
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-portfolio\"></i>
                        </div>
                        <div class=\"text\">
                            <p>All appointments sync with your Google calendar so your availability is always up to
                                date. See your schedule at a glance from any device.</p>
                        </div>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-portfolio\"></i>
                        </div>
                        <p>Automatic text and email reminders make sure customers always remember their upcoming
                            appointments.</p>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-portfolio\"></i>
                        </div>
                        <p>Take payments and run your business on the go, in your store and then see how it all adds up
                            with analytics.</p>
                    </div>
                </div>
            </div>
        </div>
    </div> <!--/CARDS DOCS-->


    <!--CARDS FORMULES-->
    <div class=\"section section-features\">
        <div class=\"container\">
            <h2 id=\"formules\" class=\"header-text text-center\">Formules</h2>
            <div class=\"row\">
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-magic-wand\"></i>
                        </div>
                        <div class=\"text\">
                            <h3>Gratuit</h3>
                            <h3>0€ <span>/mois</span></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto magnam, consequatur sint
                                officiis. Blanditiis numquam officia nobis id iure sed doloribus, adipisci, maiores
                                harum totam ratione ad nostrum ipsum iste?</p>

                        </div>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-pendrive\"></i>
                        </div>
                        <h3>Plus</h3>
                        <h3>5.50€ <span>/mois</span></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione tempora vero nemo placeat
                            fuga, vitae pariatur dolorum ab! Doloribus qui autem fugiat voluptate tempore, eaque
                            perferendis quibusdam tempora, quis arc</p>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-server\"></i>
                        </div>
                        <h3>Pro</h3>
                        <h3>15.90€ <span>/mois</span></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae in libero voluptatibus ut,
                            eaque provident blanditiis aut impedit modi quos laboriosam repellat iste quia tenetur
                            sapiente. Quasi expedita, exercitationem a!</p>
                    </div>
                </div>
            </div>
        </div>
    </div> <!--/CARDS FORMULES-->
{% endblock %}
", "home/home.html.twig", "C:\\xampp\\htdocs\\billydocs\\billydocs\\billydocs-master\\templates\\home\\home.html.twig");
    }
}
