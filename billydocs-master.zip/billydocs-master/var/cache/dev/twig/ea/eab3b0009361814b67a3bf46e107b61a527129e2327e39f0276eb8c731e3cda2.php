<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/_nav.html.twig */
class __TwigTemplate_6515f2b98ed977df855101f59e721d86c91a1f0842dbd4f6e1335b9884da31a8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "components/_nav.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "components/_nav.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-transparent navbar-top\" role=\"navigation\">
    <div class=\"container\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
            <button id=\"menu-toggle\" type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#example\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar bar1\"></span>
                <span class=\"icon-bar bar2\"></span>
                <span class=\"icon-bar bar3\"></span>
            </button>
            <a href=\"#\">
                <div class=\"logo-container\">
                    <div class=\"logo\">
                        <img src=\"assets/img/billy/billydoclogo.png\" alt=\"billydocsLogo\">
                    </div>
                </div>
            </a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse\" id=\"example\">
            <ul class=\"nav navbar-nav navbar-right\">
                <li>
                    <a href=\"inscription.html\">
                        <button id=\"boutondeconnexion\" type=\"button\" class=\"btn btn-outline-primary\">Inscription</button>
                    </a>
                </li>
            </ul>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse\" id=\"example\">
            <ul class=\"nav navbar-nav navbar-right\">
                <li>
                    <a href=\"connexion.html\">
                        <button id=\"boutondeconnexion\" type=\"button\" class=\"btn btn-outline-primary\">Connexion</button>
                    </a>
                </li>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
</nav>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "components/_nav.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"navbar navbar-transparent navbar-top\" role=\"navigation\">
    <div class=\"container\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
            <button id=\"menu-toggle\" type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#example\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar bar1\"></span>
                <span class=\"icon-bar bar2\"></span>
                <span class=\"icon-bar bar3\"></span>
            </button>
            <a href=\"#\">
                <div class=\"logo-container\">
                    <div class=\"logo\">
                        <img src=\"assets/img/billy/billydoclogo.png\" alt=\"billydocsLogo\">
                    </div>
                </div>
            </a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse\" id=\"example\">
            <ul class=\"nav navbar-nav navbar-right\">
                <li>
                    <a href=\"inscription.html\">
                        <button id=\"boutondeconnexion\" type=\"button\" class=\"btn btn-outline-primary\">Inscription</button>
                    </a>
                </li>
            </ul>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse\" id=\"example\">
            <ul class=\"nav navbar-nav navbar-right\">
                <li>
                    <a href=\"connexion.html\">
                        <button id=\"boutondeconnexion\" type=\"button\" class=\"btn btn-outline-primary\">Connexion</button>
                    </a>
                </li>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
</nav>", "components/_nav.html.twig", "C:\\xampp\\htdocs\\billydocs\\billydocs\\billydocs-master\\templates\\components\\_nav.html.twig");
    }
}
