<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/create.html.twig */
class __TwigTemplate_2b629d4abab5b033d5cb0bf39de93b9c1ba6bbf0ecf9187faba7528f8740948d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/create.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/create.html.twig"));

        // line 1
        echo "
";
        // line 3
        echo "
";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "
";
        // line 12
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "    Inscription/connexion
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "    <link rel=\"stylesheet\" href=\"css/bootstrap.min.css\">
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 12
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col\">
                &nbsp;</div>
            <div class=\"bg-light py-3 px-3\">
                <h1>BILLYDOCS</h1>
                <form action=\"";
        // line 20
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("log");
        echo "\" method=\"post\">
                    <div class=\"form-group\">
                        <input type=\"text\" name=\"_lastname\" id=\"email\" class=\"form-control\"
                               placeholder=\"votre email...\"required>
                    </div>
                    <div class=\"form-group\">
                        <input type=\"text\" name=\"_password\" id=\"password\" class=\"form-control\"
                               placeholder=\"votre password...\"required>
                    </div>
                    <button type=\"submit\" class=\"btn btn-success\">Connexion</button>
                </form>

                <input type=\"email\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new RuntimeError('Variable "last_username" does not exist.', 32, $this->source); })()), "html", null, true);
        echo "\" name=\"email\" id=\"inputEmail\" class=\"form-control\" required autofocus>





            </div>
        </div>
    </div>



















    <div class=\"container md-7 \">
        <div class=\"row d-flex flex-column mx-auto\">
            <div class=\"col-md-6 border border-primary mx-auto\">
                <div class=\"col-12\">
                    <div class=\"col-12 d-block\">
                        <h1 class=\"text-center\">BILLYDOCS</h1>
                        ";
        // line 66
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 66, $this->source); })()), 'form');
        echo "
                    </div>
                    <div class=\"col-12 d-block\">
                        ";
        // line 69
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["formname"]) || array_key_exists("formname", $context) ? $context["formname"] : (function () { throw new RuntimeError('Variable "formname" does not exist.', 69, $this->source); })()), 'form');
        echo "
                    </div>
                </div>



                <div class=\"col-md-6 d-inline mx-auto\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            ";
        // line 78
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["formfirst"]) || array_key_exists("formfirst", $context) ? $context["formfirst"] : (function () { throw new RuntimeError('Variable "formfirst" does not exist.', 78, $this->source); })()), 'form');
        echo "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 81
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["formlog"]) || array_key_exists("formlog", $context) ? $context["formlog"] : (function () { throw new RuntimeError('Variable "formlog" does not exist.', 81, $this->source); })()), 'form');
        echo "
                        </div>
                    </div>

                </div>
            </div>





        </div>
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "user/create.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  209 => 81,  203 => 78,  191 => 69,  185 => 66,  148 => 32,  133 => 20,  124 => 13,  114 => 12,  103 => 9,  93 => 8,  82 => 5,  72 => 4,  62 => 12,  59 => 11,  57 => 8,  54 => 7,  52 => 4,  49 => 3,  46 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
{#{% form_theme form 'bootstrap_4_layout.html.twig' %}#}

{% block title %}
    Inscription/connexion
{% endblock %}

{% block stylesheets %}
    <link rel=\"stylesheet\" href=\"css/bootstrap.min.css\">
{% endblock %}

{% block  body %}

    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col\">
                &nbsp;</div>
            <div class=\"bg-light py-3 px-3\">
                <h1>BILLYDOCS</h1>
                <form action=\"{{ path('log') }}\" method=\"post\">
                    <div class=\"form-group\">
                        <input type=\"text\" name=\"_lastname\" id=\"email\" class=\"form-control\"
                               placeholder=\"votre email...\"required>
                    </div>
                    <div class=\"form-group\">
                        <input type=\"text\" name=\"_password\" id=\"password\" class=\"form-control\"
                               placeholder=\"votre password...\"required>
                    </div>
                    <button type=\"submit\" class=\"btn btn-success\">Connexion</button>
                </form>

                <input type=\"email\" value=\"{{ last_username }}\" name=\"email\" id=\"inputEmail\" class=\"form-control\" required autofocus>





            </div>
        </div>
    </div>



















    <div class=\"container md-7 \">
        <div class=\"row d-flex flex-column mx-auto\">
            <div class=\"col-md-6 border border-primary mx-auto\">
                <div class=\"col-12\">
                    <div class=\"col-12 d-block\">
                        <h1 class=\"text-center\">BILLYDOCS</h1>
                        {{ form(form) }}
                    </div>
                    <div class=\"col-12 d-block\">
                        {{ form(formname) }}
                    </div>
                </div>



                <div class=\"col-md-6 d-inline mx-auto\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            {{ form(formfirst) }}
                        </div>
                        <div class=\"col-md-6\">
                            {{ form(formlog) }}
                        </div>
                    </div>

                </div>
            </div>





        </div>
    </div>

{% endblock %}
", "user/create.html.twig", "C:\\xampp\\htdocs\\billydocs\\billydocs\\billydocs-master\\templates\\user\\create.html.twig");
    }
}
