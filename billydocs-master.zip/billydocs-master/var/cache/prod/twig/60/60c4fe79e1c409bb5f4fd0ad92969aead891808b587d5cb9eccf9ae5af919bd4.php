<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/home.html.twig */
class __TwigTemplate_46da212c90108bd679af5b692b8804691ce9bcf27e75dd79e818f2a291ade74a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "home/home.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        $this->loadTemplate("components/_nav.html.twig", "home/home.html.twig", 4)->display($context);
        // line 5
        echo "    <div class=\"section section-features\">
        <div class=\"container\">
            <h2 class=\"header-text text-center\">Vos documents</h2>
            <div class=\"row\">
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-portfolio\"></i>
                        </div>
                        <div class=\"text\">
                            <p>All appointments sync with your Google calendar so your availability is always up to
                                date. See your schedule at a glance from any device.</p>
                        </div>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-portfolio\"></i>
                        </div>
                        <p>Automatic text and email reminders make sure customers always remember their upcoming
                            appointments.</p>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-portfolio\"></i>
                        </div>
                        <p>Take payments and run your business on the go, in your store and then see how it all adds up
                            with analytics.</p>
                    </div>
                </div>
            </div>
        </div>
    </div> <!--/CARDS DOCS-->


    <!--CARDS FORMULES-->
    <div class=\"section section-features\">
        <div class=\"container\">
            <h2 id=\"formules\" class=\"header-text text-center\">Formules</h2>
            <div class=\"row\">
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-magic-wand\"></i>
                        </div>
                        <div class=\"text\">
                            <h3>Gratuit</h3>
                            <h3>0€ <span>/mois</span></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto magnam, consequatur sint
                                officiis. Blanditiis numquam officia nobis id iure sed doloribus, adipisci, maiores
                                harum totam ratione ad nostrum ipsum iste?</p>

                        </div>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-pendrive\"></i>
                        </div>
                        <h3>Plus</h3>
                        <h3>5.50€ <span>/mois</span></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione tempora vero nemo placeat
                            fuga, vitae pariatur dolorum ab! Doloribus qui autem fugiat voluptate tempore, eaque
                            perferendis quibusdam tempora, quis arc</p>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"card card-blue\">
                        <div class=\"icon\">
                            <i class=\"pe-7s-server\"></i>
                        </div>
                        <h3>Pro</h3>
                        <h3>15.90€ <span>/mois</span></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae in libero voluptatibus ut,
                            eaque provident blanditiis aut impedit modi quos laboriosam repellat iste quia tenetur
                            sapiente. Quasi expedita, exercitationem a!</p>
                    </div>
                </div>
            </div>
        </div>
    </div> <!--/CARDS FORMULES-->
";
    }

    public function getTemplateName()
    {
        return "home/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 5,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "home/home.html.twig", "C:\\xampp\\htdocs\\billydocs\\billydocs\\billydocs-master\\templates\\home\\home.html.twig");
    }
}
