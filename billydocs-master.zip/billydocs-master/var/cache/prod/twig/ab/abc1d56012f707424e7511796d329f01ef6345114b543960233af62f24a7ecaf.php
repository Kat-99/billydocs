<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/_params.html.twig */
class __TwigTemplate_d9526aacd0109c2fad2a99fc421c92bb5fe814dec2e857c7c5c94b47b149dbe4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "
<div class=\"fixed-plugin\">
    <div class=\"dropdown toggle\">
        <a href=\"#\" data-toggle=\"dropdown\">
            <i class=\"fa fa-cog fa-2x\"> </i>
        </a>
        <ul class=\"dropdown-menu\">
            ";
        // line 14
        echo "
            <h4> Mes parametres</h4>

            <li class=\"\">
                <a href=\"http://localhost:8000/profil\" class=\"switch\">
                    <button id=\"boutonformule\" type=\"button\" class=\"btn btn-outline-primary\">Modifier mon profil
                    </button>
                </a>
            </li>

            <li class=\"\">
                <a href=\"http://localhost:8000/updatemdp\" class=\"switch\">
                    <button id=\"boutonformule\" type=\"button\" class=\"btn btn-outline-primary\">Modifier mon mot de passe
                    </button>
                </a>
            </li>


        </ul>
    </div>
</div> <!--/PARAMETRE-->
";
    }

    public function getTemplateName()
    {
        return "components/_params.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  46 => 14,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "components/_params.html.twig", "C:\\xampp\\htdocs\\billydocs\\billydocs\\billydocs-master\\templates\\components\\_params.html.twig");
    }
}
