<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/create.html.twig */
class __TwigTemplate_0afd07824e964f98d7a712fb6548c19833d0d6e9325b87c5ed15e0bc6e45561d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "
";
        // line 3
        echo "
";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "
";
        // line 12
        $this->displayBlock('body', $context, $blocks);
    }

    // line 4
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 5
        echo "    Inscription/connexion
";
    }

    // line 8
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 9
        echo "    <link rel=\"stylesheet\" href=\"css/bootstrap.min.css\">
";
    }

    // line 12
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 13
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col\">
                &nbsp;</div>
            <div class=\"bg-light py-3 px-3\">
                <h1>BILLYDOCS</h1>
                <form action=\"";
        // line 20
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("log");
        echo "\" method=\"post\">
                    <div class=\"form-group\">
                        <input type=\"text\" name=\"_lastname\" id=\"email\" class=\"form-control\"
                               placeholder=\"votre email...\"required>
                    </div>
                    <div class=\"form-group\">
                        <input type=\"text\" name=\"_password\" id=\"password\" class=\"form-control\"
                               placeholder=\"votre password...\"required>
                    </div>
                    <button type=\"submit\" class=\"btn btn-success\">Connexion</button>
                </form>

                <input type=\"email\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, ($context["last_username"] ?? null), "html", null, true);
        echo "\" name=\"email\" id=\"inputEmail\" class=\"form-control\" required autofocus>





            </div>
        </div>
    </div>



















    <div class=\"container md-7 \">
        <div class=\"row d-flex flex-column mx-auto\">
            <div class=\"col-md-6 border border-primary mx-auto\">
                <div class=\"col-12\">
                    <div class=\"col-12 d-block\">
                        <h1 class=\"text-center\">BILLYDOCS</h1>
                        ";
        // line 66
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form');
        echo "
                    </div>
                    <div class=\"col-12 d-block\">
                        ";
        // line 69
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["formname"] ?? null), 'form');
        echo "
                    </div>
                </div>



                <div class=\"col-md-6 d-inline mx-auto\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            ";
        // line 78
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["formfirst"] ?? null), 'form');
        echo "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 81
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["formlog"] ?? null), 'form');
        echo "
                        </div>
                    </div>

                </div>
            </div>





        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "user/create.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  167 => 81,  161 => 78,  149 => 69,  143 => 66,  106 => 32,  91 => 20,  82 => 13,  78 => 12,  73 => 9,  69 => 8,  64 => 5,  60 => 4,  56 => 12,  53 => 11,  51 => 8,  48 => 7,  46 => 4,  43 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "user/create.html.twig", "C:\\xampp\\htdocs\\billydocs\\billydocs\\billydocs-master\\templates\\user\\create.html.twig");
    }
}
