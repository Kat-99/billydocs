<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/_footer.html.twig */
class __TwigTemplate_db21e0fade6df8ba5cb4be5f15d386cfbdf0e5569110773d05e1b24dd29bb5c0 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!--FOOTER-->
<footer class=\"footer\">
    <div class=\"container\">
        <nav class=\"pull-left\">
            <ul>
                <li>
                    <a href=\"#\">
                        Contact
                    </a>
                </li>
            </ul>
        </nav>
        <div class=\"copyright\">
            &copy; 2019 <a href=\"#\">BillyDocs</a>
        </div>
    </div>
</footer> <!--/FOOTER-->";
    }

    public function getTemplateName()
    {
        return "components/_footer.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "components/_footer.html.twig", "C:\\xampp\\htdocs\\billydocs\\billydocs\\billydocs-master\\templates\\components\\_footer.html.twig");
    }
}
